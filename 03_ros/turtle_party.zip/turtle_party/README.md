# turtle_party

This ROS 2 package creates a turtle party in the turtlesim simulator. Multiple turtles are spawned, and each turtle follows its predecessor in a chain formation.

## Features

- `turtle1` moves randomly around the map.
- `turtle2` follows `turtle1`, `turtle3` follows `turtle2`, and so on.

## How to Run

cd ~/ros2_ws
colcon build
source install/setup.bash
ros2 launch turtle_party turtles_gone_wild.launch.py amount:=3 or x

## Package Structure

turtle_party/
├── launch/
│   └── turtles_gone_wild.launch.py
├── turtle_party/
│   ├── turtle_follower.py
│   ├── turtle1_mover.py
│   └── turtle_tf_broadcaster.py
├── package.xml
├── setup.py
├── setup.cfg
└── README.md
