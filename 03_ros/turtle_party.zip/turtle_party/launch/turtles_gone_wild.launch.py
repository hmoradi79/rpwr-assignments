from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, TimerAction, OpaqueFunction
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
import subprocess
import time

def spawn_turtles(context, *args, **kwargs):
    amount = int(LaunchConfiguration('amount').perform(context))

    for i in range(10):
        result = subprocess.run(['ros2', 'service', 'list'], capture_output=True, text=True)
        if '/spawn' in result.stdout:
            break
        time.sleep(1)
    else:
        print("Timeout waiting for /spawn service.")
        return []

    for i in range(2, amount + 1):
        name = f"turtle{i}"
        x = 2.0 + i
        y = 2.0 + i
        theta = 0.0
        cmd = [
            'ros2', 'service', 'call',
            '/spawn', 'turtlesim/srv/Spawn',
            f"x: {x}\ny: {y}\ntheta: {theta}\nname: '{name}'"
        ]
        subprocess.run(cmd)
    
    return []

def generate_launch_description():
    amount = LaunchConfiguration('amount')
    return LaunchDescription([
        DeclareLaunchArgument('amount', default_value='3'),

        Node(
            package='turtlesim',
            executable='turtlesim_node',
            name='sim'
        ),

        Node(
            package='turtle_party',
            executable='turtle1_mover',
            name='turtle1_mover'
        ),

        Node(
            package='turtle_party',
            executable='turtle_tf_broadcaster',
            name='turtle1_tf',
            arguments=['turtle1']
        ),

        TimerAction(
            period=5.0,
            actions=[
                OpaqueFunction(function=spawn_turtles)
            ]
        ),

        TimerAction(
            period=8.0,
            actions=[
                OpaqueFunction(function=lambda context, *args, **kwargs: [
                    Node(
                        package='turtle_party',
                        executable='turtle_tf_broadcaster',
                        name=f'turtle{i}_tf',
                        arguments=[f'turtle{i}']
                    )
                    for i in range(2, int(LaunchConfiguration('amount').perform(context)) + 1)
                ] + [
                    Node(
                        package='turtle_party',
                        executable='turtle_follower',
                        name=f'turtle{i}_follower',
                        arguments=[f'turtle{i}', f'turtle{i-1}']
                    )
                    for i in range(2, int(LaunchConfiguration('amount').perform(context)) + 1)
                ])
            ]
        )
    ])

