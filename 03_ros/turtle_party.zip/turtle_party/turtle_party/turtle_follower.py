import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from turtlesim.msg import Pose
from tf2_ros import TransformException, TransformListener, Buffer
import math
import sys


class TurtleFollower(Node):

    def __init__(self, name, leader='turtle1'):
        super().__init__('{}_follower'.format(name))
        self.name = name
        self.leader = leader
        self.follower = name

        self.tf_buffer = Buffer()
        self.tf_listener = TransformListener(self.tf_buffer, self)

        self.cmd_vel_publisher = self.create_publisher(
            Twist,
            '/{}/cmd_vel'.format(self.follower),
            10
        )

        self.timer = self.create_timer(0.1, self.follow_leader)

    def follow_leader(self):
        try:
            # اصلاح شده: برعکس کردن ترتیب فریم‌ها
            trans = self.tf_buffer.lookup_transform(
                self.follower,   # target_frame (لاک‌پشت ما)
                self.leader,     # source_frame (رهبر)
                rclpy.time.Time()
            )
        except TransformException as ex:
            self.get_logger().info(f'Could not transform {self.follower} to {self.leader}: {ex}')
            return

        msg = Twist()
        msg.linear.x = 1.0 * math.sqrt(
            trans.transform.translation.x ** 2 +
            trans.transform.translation.y ** 2
        )
        msg.angular.z = 4.0 * math.atan2(
            trans.transform.translation.y,
            trans.transform.translation.x
        )

        self.cmd_vel_publisher.publish(msg)


def main():
    rclpy.init()
    if len(sys.argv) < 3:
        print("Usage: turtle_follower.py <follower_name> <leader_name>")
        return

    follower_name = sys.argv[1]
    leader_name = sys.argv[2]

    follower_node = TurtleFollower(follower_name, leader=leader_name)
    rclpy.spin(follower_node)
    follower_node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()

