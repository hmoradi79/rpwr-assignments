import rclpy
from rclpy.node import Node
from turtlesim.msg import Pose
from geometry_msgs.msg import TransformStamped
from tf2_ros import TransformBroadcaster
import math


class TurtleTFBroadcaster(Node):
    def __init__(self, turtle_name):
        super().__init__('turtle_tf_broadcaster_' + turtle_name)
        self.turtle_name = turtle_name

        self.tf_broadcaster = TransformBroadcaster(self)
        self.subscription = self.create_subscription(
            Pose,
            f'/{self.turtle_name}/pose',
            self.handle_turtle_pose,
            10
        )

    def handle_turtle_pose(self, msg: Pose):
        t = TransformStamped()
        t.header.stamp = self.get_clock().now().to_msg()
        t.header.frame_id = 'world'
        t.child_frame_id = self.turtle_name
        t.transform.translation.x = msg.x
        t.transform.translation.y = msg.y
        t.transform.translation.z = 0.0


        qz = math.sin(msg.theta * 0.5)
        qw = math.cos(msg.theta * 0.5)
        t.transform.rotation.x = 0.0
        t.transform.rotation.y = 0.0
        t.transform.rotation.z = qz
        t.transform.rotation.w = qw

        self.tf_broadcaster.sendTransform(t)


def main(args=None):
    rclpy.init(args=args)
    import sys
    turtle_name = sys.argv[1] if len(sys.argv) > 1 else 'turtle1'
    node = TurtleTFBroadcaster(turtle_name)
    rclpy.spin(node)
    rclpy.shutdown()
