
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
import random


class Turtle1Mover(Node):
    def __init__(self):
        super().__init__('turtle1_mover')
        self.publisher = self.create_publisher(Twist, '/turtle1/cmd_vel', 10)
        self.timer = self.create_timer(1.0, self.move_randomly)

    def move_randomly(self):
        msg = Twist()
        msg.linear.x = random.uniform(0.5, 2.0)
        msg.angular.z = random.uniform(-2.0, 2.0)
        self.publisher.publish(msg)


def main(args=None):
    rclpy.init(args=args)
    node = Turtle1Mover()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

